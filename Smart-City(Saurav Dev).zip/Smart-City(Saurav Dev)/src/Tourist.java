public class Tourist extends User {
    public Tourist(String name, String pass){
        super(name,pass);
    }
}
