public class hotels_controller {

}
